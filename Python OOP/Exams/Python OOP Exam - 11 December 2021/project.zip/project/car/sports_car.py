from project.car.car import Car


class SportsCar(Car):
    minimum_speed = 400
    maximum_speed = 600

    def __init__(self, model, speed_limit):
        super().__init__(model, speed_limit)

