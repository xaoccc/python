from project.car.car import Car


class MuscleCar(Car):
    minimum_speed = 250
    maximum_speed = 450

    def __init__(self, model, speed_limit):
        super().__init__(model, speed_limit)






