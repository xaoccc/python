from project.planet.planet_repository import PlanetRepository
from project.astronaut.astronaut_repository import AstronautRepository
from project.astronaut.biologist import Biologist
from project.astronaut.meteorologist import Meteorologist
from project.astronaut.geodesist import Geodesist
from project.planet.planet import Planet


class SpaceStation:
    astronaut_types = {"Biologist": Biologist, "Meteorologist": Meteorologist, "Geodesist": Geodesist}
    successful_missions, failed_missions = 0, 0

    def __init__(self):
        self.planet_repository = PlanetRepository()
        self.astronaut_repository = AstronautRepository()

    def add_astronaut(self, astronaut_type: str, name: str):
        if astronaut_type not in self.astronaut_types:
            raise Exception("Astronaut type is not valid!")

        if self.astronaut_repository.find_by_name(name):
            return f"{name} is already added."

        self.astronaut_repository.add(self.astronaut_types[astronaut_type](name))
        return f"Successfully added {astronaut_type}: {name}."

    def add_planet(self, name: str, items: str):
        if self.planet_repository.find_by_name(name):
            return f"{name} is already added."

        self.planet_repository.add(Planet(name))
        self.planet_repository.planets[-1].items += items.split(", ")
        return f"Successfully added Planet: {name}."

    def retire_astronaut(self, name: str):
        astronaut = self.astronaut_repository.find_by_name(name)
        if not astronaut:
            raise Exception(f"Astronaut {name} doesn't exist!")

        self.astronaut_repository.remove(astronaut)
        return f"Astronaut {name} was retired!"

    def recharge_oxygen(self):
        for astronaut in self.astronaut_repository.astronauts:
            astronaut.increase_oxygen(10)

    def send_on_mission(self, planet_name: str):
        if not self.planet_repository.find_by_name(planet_name):
            raise Exception("Invalid planet name!")

        suitable_astronauts = []
        for astronaut in self.astronaut_repository.astronauts:
            if astronaut.oxygen > 30:
                suitable_astronauts.append(astronaut)
        if not suitable_astronauts:
            raise Exception("You need at least one astronaut to explore the planet!")

        planet = self.planet_repository.find_by_name(planet_name)

        suitable_astronauts = sorted(suitable_astronauts, key=lambda a: -a.oxygen)[:5]
        participating_astronauts = []
        for astronaut in suitable_astronauts:
            while astronaut.oxygen > 0:
                # if astronaut.oxygen < astronaut.AIR:
                #     break
                if astronaut.name not in participating_astronauts:
                    participating_astronauts.append(astronaut.name)

                astronaut.backpack.append(planet.items.pop())
                astronaut.breathe()

                if not planet.items:
                    self.successful_missions += 1
                    return f"Planet: {planet_name} was explored. {len(participating_astronauts)} astronauts participated in collecting items."

        if planet.items:
            self.failed_missions += 1
            return "Mission is not completed."

    def report(self):
        result = [f"{self.successful_missions} successful missions!\n"
                  f"{self.failed_missions} missions were not completed!\nAstronauts' info:"]
        for astronaut in self.astronaut_repository.astronauts:
            result.append(f"Name: {astronaut.name}\nOxygen: {astronaut.oxygen}")
            if astronaut.backpack:
                result.append(f"Backpack items: {', '.join(astronaut.backpack)}")
            else:
                result.append(f"Backpack items: none")

        return str("\n".join(result))



# station = SpaceStation()
# for a in station.astronaut_repository.astronauts:
#     print(a.__class__.__name__, a.name, a.oxygen)
# for p in station.planet_repository.planets:
#     print(p.__class__.__name__, p.name, p.items)
# print(station.add_astronaut("Biologist", "Evlogi"))
# print(station.add_astronaut("Meteorologist", "Lora"))
# print(station.add_astronaut("Geodesist", "Kamen"))
# # print all astronauts
# for a in station.astronaut_repository.astronauts:
#     print(a.__class__.__name__, a.name, a.oxygen)
# # check add same type same name
# print(station.add_astronaut("Meteorologist", "Lora"))
# # check add diff type same name
# print(station.add_astronaut("Biologist", "Lora"))
#
# print(station.retire_astronaut("Kamen"))
# for a in station.astronaut_repository.astronauts:
#     print(a.__class__.__name__, a.name, a.oxygen)
#
# print(station.add_planet("Pluto", "gold"))
# print(station.add_planet("Melmak", "old computer, cat, another,cat, gold, more,gold, lego, bottle, gems, Nakov textbook,"))
# # print all planets
# for p in station.planet_repository.planets:
#     print(p.__class__.__name__, p.name, p.items)
# # check add same name
# print(station.add_planet("Melmak", "silver"))
# station.recharge_oxygen()
# for a in station.astronaut_repository.astronauts:
#     print(a.__class__.__name__, a.name, a.oxygen)
#
# print("\n")
# print(station.add_astronaut("Geodesist", "Zdravko"))
# print(station.add_astronaut("Biologist", "Jenata na Zdravko"))
# print(station.add_astronaut("Biologist", "Liubovnicata na Zdravko"))
# print(station.add_astronaut("Geodesist", "Unufri"))
# print("\n")
# print(station.planet_repository.planets[-1].items)
# print(station.send_on_mission("Melmak"))
# print(station.planet_repository.planets[-1].items)
# print(station.report())


station = SpaceStation()

print(f"\n\n# CREATING ASTRONAUTS")
print(station.add_astronaut('Biologist', 'B'))
print(station.add_astronaut('Biologist', 'B Senior'))
print(station.add_astronaut('Meteorologist', 'M'))
print(station.add_astronaut('Geodesist', 'G'))

print(f"\n\n# CREATING PLANETS")
print(station.add_planet('Mars', '1_item, 2_item, 3_item, 4_item, 5_item, 6_item', ))
print(station.add_planet('Earth', 'bananas'))
print(station.add_planet('Jupiter', 'stone, gems, sand,stone, gems, sand,stone, gems, sand'))
print(station.add_planet('Fail Planet', 'stone, gems, sand,stone, gems, sand,stone, gems, sand,stone, gems, sand,stone,'
                                        ' gems,sand,stone, gems, sand,stone, gems, sand,stone, gems, sand,stone, gems,'
                                        ' sand,stone, gems, sand,stone, gems, sand,stone, gems, sand'))
print(station.add_planet('Mars', 'stone'))

print(f"\n\n# RETIRE ASTRONAUT")
print(station.retire_astronaut('B Senior'))

print(f"\n\n# ASTRONAUTS INFO ")
for a in station.astronaut_repository.astronauts:
    print(a.oxygen, a.name, a.__class__.__name__)

print(f"\n\n# ASTRONAUTS INFO - AFTER RECHARGE")
station.recharge_oxygen()
for a in station.astronaut_repository.astronauts:
    print(a.oxygen, a.name, a.__class__.__name__)

print(f"\n\n# TEST SEND ON MISSION")
print(station.send_on_mission('Mars'))
print(station.send_on_mission('Jupiter'))
print(station.send_on_mission('Earth'))
print(station.send_on_mission('Fail Planet'))

print(f"\n\n# TEST REPORT")
station.add_astronaut('Biologist', 'Mr.Empty Backpack')
print(station.report())